# Databricks notebook source
products_df=spark.read.format("parquet")\
    .option("header",True)\
        .option("inferSchema",True)\
            .load("abfss://bronze@sagen2dbproject2.dfs.core.windows.net/products")\
                .drop('_rescued_data')


# COMMAND ----------


dimproducts=products_df.dropDuplicates()

dimproducts.createOrReplaceTempView("dimproducts")


# COMMAND ----------


dimproducts.write.format("delta")\
    .mode('overwrite')\
        .save("abfss://silver@sagen2dbproject2.dfs.core.windows.net/dimproducts")

# COMMAND ----------

# MAGIC %md
# MAGIC # Creating table in silver schema

# COMMAND ----------

# MAGIC %sql
# MAGIC create table if not exists dbproject2.silver.products
# MAGIC using delta
# MAGIC as
# MAGIC select * from dimproducts;