# Databricks notebook source
orders_df = spark.readStream.format("cloudFiles")\
    .option("cloudFiles.format", "csv")\
    .option("header", True)\
    .option("inferSchema", True)\
    .option("cloudFiles.schemaLocation", "abfss://bronze@sagen2dbproject2.dfs.core.windows.net/checkpoint_orders")\
    .load("abfss://source@sagen2dbproject2.dfs.core.windows.net/orders")

# COMMAND ----------

orders_df.display()

# COMMAND ----------

orders_df.writeStream.format("csv") \
    .outputMode("append") \
    .option("checkpointLocation", "abfss://bronze@sagen2dbproject2.dfs.core.windows.net/checkpoint_orders") \
    .option("path", "abfss://bronze@sagen2dbproject2.dfs.core.windows.net/orders") \
    .trigger(once=True) \
    .start()