# Databricks notebook source
P_file_name=dbutils.widgets.get("File_name")

# COMMAND ----------

orders_df = spark.readStream.format("cloudFiles")\
    .option("cloudFiles.format", "csv")\
    .option("header", True)\
    .option("inferSchema", True)\
    .option("cloudFiles.schemaLocation", f"abfss://bronze@sagen2dbproject2.dfs.core.windows.net/checkpoint_{P_file_name}")\
    .load(f"abfss://source@sagen2dbproject2.dfs.core.windows.net/{P_file_name}")

# COMMAND ----------

orders_df.writeStream.format("parquet") \
    .outputMode("append") \
    .option("checkpointLocation", f"abfss://bronze@sagen2dbproject2.dfs.core.windows.net/checkpoint_{P_file_name}") \
    .option("path", f"abfss://bronze@sagen2dbproject2.dfs.core.windows.net/{P_file_name}") \
    .trigger(once=True) \
    .start()