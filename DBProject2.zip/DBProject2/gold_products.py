# Databricks notebook source
from pyspark.sql.functions import *

# COMMAND ----------

products_df=spark.read.format("delta")\
    .option("infraSchema",True)\
        .load("abfss://silver@sagen2dbproject2.dfs.core.windows.net/dimproducts")


# COMMAND ----------

products_df.write.format("parquet")\
    .mode("overwrite")\
        .save("abfss://gold@sagen2dbproject2.dfs.core.windows.net/products/products_final")

# COMMAND ----------

