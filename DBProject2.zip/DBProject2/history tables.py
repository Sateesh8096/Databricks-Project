# Databricks notebook source
from delta.tables import DeltaTable

# Load Delta table from path
delta_table = DeltaTable.forPath(spark, "abfss://silver@sagen2dbproject2.dfs.core.windows.net/dimcustomers")

# Show table history
delta_table1=delta_table.history().show(truncate=False)

delta_table1.display()
