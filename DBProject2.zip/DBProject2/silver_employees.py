# Databricks notebook source
employees_df=spark.read.format("parquet")\
    .option("header",True)\
        .option("inferSchema",True)\
            .load("abfss://bronze@sagen2dbproject2.dfs.core.windows.net/employees")\
                .drop('_rescued_data')

display(employees_df)


# COMMAND ----------

dimemployees=employees_df.dropDuplicates()

dimemployees.createOrReplaceTempView("dimemployees")

# COMMAND ----------

dimemployees.write.format("delta")\
    .mode('overwrite')\
        .save("abfss://silver@sagen2dbproject2.dfs.core.windows.net/dimemployees")

# COMMAND ----------

# MAGIC %md
# MAGIC # Creating table in silver schema

# COMMAND ----------

# MAGIC %sql
# MAGIC create table if not exists dbproject2.silver.employees
# MAGIC using delta
# MAGIC as
# MAGIC select * from dimemployees;