# Databricks notebook source
from pyspark.sql.functions import  *

customer_df=spark.read.format("delta")\
    .option("infraSchema",True)\
        .load("abfss://silver@sagen2dbproject2.dfs.core.windows.net/dimcustomers")

customer_df=customer_df.withColumn("created_date", col("created_date").cast("date"))\
    .withColumn("updated_date", col("updated_date").cast("date"))


customer_final = customer_df.withColumn("created_year", date_format(col("created_date"), "yyyy"))\
    .withColumn("created_month", date_format(col("created_date"), "MMMM"))\
        .withColumn("created_day", date_format(col("created_date"), "dd"))\
            .withColumn("updated_year", date_format(col("updated_date"), "yyyy"))\
                .withColumn("updated_month", date_format(col("updated_date"), "MMMM"))\
                    .withColumn("updated_day", date_format(col("updated_date"), "dd"))

customer_final.display()

# COMMAND ----------

customer_final.write.format("delta")\
    .mode("overwrite")\
        .save("abfss://gold@sagen2dbproject2.dfs.core.windows.net/customers/customer_final")