# Databricks notebook source
from pyspark.sql.functions import *

# COMMAND ----------

employees_df=spark.read.format("delta")\
    .option("infraSchema",True)\
        .load("abfss://silver@sagen2dbproject2.dfs.core.windows.net/dimemployees")
        
employees_df=employees_df.withColumn("hire_date",col("hire_date").cast("date"))

# COMMAND ----------

employees_df.write.format("delta")\
    .mode("overwrite")\
        .save("abfss://gold@sagen2dbproject2.dfs.core.windows.net/employees/employees_final")