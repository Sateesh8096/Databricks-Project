# Databricks notebook source
# MAGIC %md
# MAGIC # Importing the Data From Bronze  

# COMMAND ----------

customers_df=spark.read.format("parquet")\
    .option("header",True)\
        .option("inferSchema",True)\
            .load("abfss://bronze@sagen2dbproject2.dfs.core.windows.net/customers")\
                .drop('_rescued_data')

display(customers_df)

# COMMAND ----------

# MAGIC %md
# MAGIC # Creating the Dynamic Tables

# COMMAND ----------

dimcustomers=customers_df.dropDuplicates()

# COMMAND ----------

dimcustomers.write.format("delta")\
    .mode('overwrite')\
        .save("abfss://silver@sagen2dbproject2.dfs.core.windows.net/dimcustomers")

# COMMAND ----------

# MAGIC %md
# MAGIC # creating Table in Silver 

# COMMAND ----------

dimcustomers.createOrReplaceTempView("dimcustomers")

# COMMAND ----------

# MAGIC %sql
# MAGIC create table if not exists dbproject2.silver.customers
# MAGIC using delta
# MAGIC as
# MAGIC select * from dimcustomers;