# Databricks notebook source
orders_df=spark.read.format("parquet")\
    .option("header",True)\
        .option("inferSchema",True)\
            .load("abfss://bronze@sagen2dbproject2.dfs.core.windows.net/orders")\
                .drop('_rescued_data')


# COMMAND ----------

dimorders=orders_df.dropDuplicates()

dimorders.createOrReplaceTempView("dimorders")


# COMMAND ----------

dimorders.write.format("delta")\
    .mode('overwrite')\
        .save("abfss://silver@sagen2dbproject2.dfs.core.windows.net/dimorders")

# COMMAND ----------

# MAGIC %md
# MAGIC # Creating table in silver schema

# COMMAND ----------

# MAGIC %sql
# MAGIC create table if not exists dbproject2.silver.orders
# MAGIC using delta
# MAGIC as
# MAGIC select * from dimorders;