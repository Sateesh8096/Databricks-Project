# Databricks notebook source
import dlt

# COMMAND ----------

import dlt
from pyspark.sql.functions import col, lower

@dlt.table(
    name="gold_dimcustomers",
    comment="Gold layer customer table with cleaned email data"
)
def customers_dlt():
    # Load from Silver (Parquet format)
    df = spark.read.format("delta").load("abfss://silver@sagen2dbproject2.dfs.core.windows.net/dimcustomers")

    # Transform and filter data
    gold_customer_df = (
        df.filter(col("email").isNotNull())
          .withColumn("email_id", lower(col("email")))
    )

    return gold_customer_df


# COMMAND ----------

