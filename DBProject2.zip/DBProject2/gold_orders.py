# Databricks notebook source
from pyspark.sql.functions import *

# COMMAND ----------

orders_df=spark.read.format("delta")\
    .option("infraSchema",True)\
        .load("abfss://silver@sagen2dbproject2.dfs.core.windows.net/dimorders")

orders_df=orders_df.withColumn("order_date",col("order_date").cast("date"))

orders_df.display()

# COMMAND ----------

orders_df.write.format("delta")\
    .mode("overwrite")\
        .save("abfss://gold@sagen2dbproject2.dfs.core.windows.net/orders/orders_final")