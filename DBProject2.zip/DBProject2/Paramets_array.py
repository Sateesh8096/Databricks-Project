# Databricks notebook source
dataset=[
    {
        "File_name":"orders"
    },
    {
        "File_name":"employees"
    },
    {
        "File_name":"customers"
    },
    {
        "File_name":"products"
    }
]

# COMMAND ----------

dbutils.jobs.taskValues.set("output_dataset",dataset)