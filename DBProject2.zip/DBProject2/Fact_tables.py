# Databricks notebook source
customer_table=spark.read.format("delta")\
    .option("infraSchema",True)\
        .load("abfss://gold@sagen2dbproject2.dfs.core.windows.net/customers/customer_final")

customer_table.createOrReplaceTempView("customer_table")

# COMMAND ----------

orders_table=spark.read.format("delta")\
    .option("infraSchema",True)\
        .load("abfss://gold@sagen2dbproject2.dfs.core.windows.net/orders/orders_final")

orders_table.createOrReplaceTempView("orders_table")

# COMMAND ----------


customers_orders=spark.sql(""" select a.*,b.order_id,b.order_date,b.amount 
                           from customer_table a
                           left join orders_table b
                           on a.customer_id=b.customer_id
                           """)  

customers_orders.display()

# COMMAND ----------

customers_orders.write.format('delta')\
    .mode("overwrite")\
        .save("abfss://gold@sagen2dbproject2.dfs.core.windows.net/fact_tables/customers_orders_final")